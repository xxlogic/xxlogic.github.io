#!/bin/bash

source ../xilinx_vivado/build.sh
